# Initialize detector package
